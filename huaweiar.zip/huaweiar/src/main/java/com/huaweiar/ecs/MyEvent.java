package com.huaweiar.ecs;

public class MyEvent {

}
