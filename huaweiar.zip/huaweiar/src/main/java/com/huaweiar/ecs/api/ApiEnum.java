package com.huaweiar.ecs.api;

public enum ApiEnum {
	
	token, tags, ecs
	
}